import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';


class DatabaseConnection{
  // Future<Database> setDatabase() async {
  //   var directory = await getApplicationDocumentsDirectory();
  //   var path = join(directory.path, 'db_crud');
  //   var database= await openDatabase(path ,version: 1, onCreate: _createDatabase);
  //   return database;

  // }
  // Future<void>_createDatabase(Database database,int version)async{
  //   String sql = "CREATE TABLE users(id INTERGAR PRIMARY KEY, name TEXT ,contact TEXT ,description TEXT);";
  //   await database.execute(sql);
  // }

  static Database? _database;

  Future<Database?> setDatabase() async {
    if (_database == null) {
      _database = await openDatabase(
        join(await getDatabasesPath(), 'user_database.db'),
        onCreate: (db, version) {
          return db.execute(
            'CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact TEXT, description TEXT)',
          );
        },
        version: 1,
      );
    }
    return _database;
  }
}